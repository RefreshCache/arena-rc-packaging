﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Arena.Core;
using Arena.Portal;

namespace ArenaWeb.UserControls.Custom.$safeprojectname$
{
    public partial class UserControl1 : PortalControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}