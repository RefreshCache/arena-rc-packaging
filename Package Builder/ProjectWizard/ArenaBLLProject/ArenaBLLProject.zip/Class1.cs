﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Arena.Core;

namespace Arena.Custom.$safeprojectname$
{
    public class Class1
    {
        public Class1
        {

        }
    }
}